from collections import defaultdict
import re

# Input files
input_unsuccessful_channels = "channel_unsuccessful.txt"
input_combined_details = "combined_channel_details.txt"
output_filtered_details = "filtered_combined_channel_details.txt"

# Read the channel names from unsuccessful channels file
unsuccessful_channels = set()
with open(input_unsuccessful_channels, 'r', encoding='utf-8') as file:
    for line in file:
        match = re.match(r'Channel Name: (.*?) -> failed', line)
        if match:
            unsuccessful_channels.add(match.group(1))

# Filter URLs from combined_channel_details.txt that belong to unsuccessful channels
with open(input_combined_details, 'r', encoding='utf-8') as infile, \
     open(output_filtered_details, 'w', encoding='utf-8') as outfile:
    
    for line in infile:
        match = re.match(r'Channel Name: (.*?) -> URLS: \[(.*?)\]', line)
        if match:
            channel_name = match.group(1)
            if channel_name in unsuccessful_channels:
                outfile.write(line)

print("Filtered list of URLs for unsuccessful channels has been written to filtered_combined_channel_details.txt.")